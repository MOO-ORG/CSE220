public class PairNode {
    
    Integer key;
    String value;
    PairNode next;
	// YOU HAVE TO WRITE THIS CONSTRUCTOR BUT NO NEED TO SUBMIT IT
    public PairNode( Integer k, String v ){
        // TO DO
    }
    
}
